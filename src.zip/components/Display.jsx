export default function Display({value}) {
    return (
        <div className="dispaly">
            {value}
        </div>
    );
}
